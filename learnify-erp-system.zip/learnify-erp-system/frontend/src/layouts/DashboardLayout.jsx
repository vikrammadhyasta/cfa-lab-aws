import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../components/AuthContext';
import { useState } from 'react';

const navItems = {
  admin: [
    { to: '/admin/dashboard', label: 'Dashboard', icon: '📊' },
    { to: '/admin/students', label: 'Students', icon: '🎓' },
    { to: '/admin/lecturers', label: 'Lecturers', icon: '👨‍🏫' },
    { to: '/admin/courses', label: 'Courses & Subjects', icon: '📚' },
    { to: '/admin/attendance', label: 'Attendance', icon: '📋' },
    { to: '/admin/marks', label: 'Marks', icon: '📝' },
  ],
  lecturer: [
    { to: '/lecturer/dashboard', label: 'Dashboard', icon: '📊' },
    { to: '/lecturer/attendance', label: 'Attendance', icon: '📋' },
    { to: '/lecturer/marks', label: 'Marks', icon: '📝' },
  ],
  student: [
    { to: '/student/dashboard', label: 'Dashboard', icon: '📊' },
    { to: '/student/attendance', label: 'My Attendance', icon: '📋' },
    { to: '/student/marks', label: 'My Marks', icon: '📝' },
  ],
};

const roleColors = {
  admin: 'bg-purple-100 text-purple-700',
  lecturer: 'bg-blue-100 text-blue-700',
  student: 'bg-green-100 text-green-700',
};

export default function DashboardLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const items = navItems[user?.role] || [];

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-16'} transition-all duration-300 bg-white border-r border-gray-100 flex flex-col shadow-sm`}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 py-5 border-b border-gray-100">
          <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center flex-shrink-0">
            <span className="text-white font-bold font-display text-sm">L</span>
          </div>
          {sidebarOpen && (
            <span className="font-display font-bold text-primary-700 text-lg leading-none">Learnify</span>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 px-2 space-y-1 overflow-y-auto">
          {items.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
              title={!sidebarOpen ? item.label : ''}
            >
              <span className="text-lg flex-shrink-0">{item.icon}</span>
              {sidebarOpen && <span className="truncate">{item.label}</span>}
            </NavLink>
          ))}
        </nav>

        {/* User Info */}
        <div className="p-3 border-t border-gray-100">
          {sidebarOpen ? (
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-primary-700 font-semibold text-sm">
                  {user?.name?.charAt(0).toUpperCase()}
                </span>
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold text-gray-800 truncate">{user?.name}</p>
                <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${roleColors[user?.role]}`}>
                  {user?.role}
                </span>
              </div>
            </div>
          ) : (
            <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center mx-auto">
              <span className="text-primary-700 font-semibold text-sm">
                {user?.name?.charAt(0).toUpperCase()}
              </span>
            </div>
          )}
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Navbar */}
        <header className="bg-white border-b border-gray-100 px-6 py-4 flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="text-gray-500 hover:text-gray-700 transition-colors"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            <div>
              <h1 className="font-display font-bold text-gray-900 text-lg leading-none">
                🎓 Learnify ERP System
              </h1>
              <p className="text-xs text-gray-400 mt-0.5">Academic Management Portal</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-semibold text-gray-800">{user?.name}</p>
              <p className="text-xs text-gray-400">{user?.email}</p>
            </div>
            <button
              onClick={handleLogout}
              className="btn-secondary text-sm flex items-center gap-2"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
              </svg>
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
