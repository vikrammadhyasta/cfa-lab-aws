import { createContext, useContext, useState, useEffect } from 'react';
import { login as loginAPI } from '../services/api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  // Start loading=true so ProtectedRoute doesn't flash /login before localStorage is read
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    try {
      const token = localStorage.getItem('learnify_token');
      const savedUser = localStorage.getItem('learnify_user');
      if (token && savedUser) {
        setUser(JSON.parse(savedUser));
      }
    } catch (e) {
      // Corrupt localStorage — clear it
      localStorage.removeItem('learnify_token');
      localStorage.removeItem('learnify_user');
    } finally {
      setLoading(false);
    }
  }, []);

  const login = async (email, password) => {
    const res = await loginAPI({ email, password });
    const { token, user } = res.data;
    localStorage.setItem('learnify_token', token);
    localStorage.setItem('learnify_user', JSON.stringify(user));
    setUser(user);
    return user;
  };

  const logout = () => {
    localStorage.removeItem('learnify_token');
    localStorage.removeItem('learnify_user');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
