import { useEffect, useState } from 'react';
import { useAuth } from '../components/AuthContext';
import {
  getSubjects, getStudents, markAttendance,
  getAttendanceBySubject, getStudentAttendance
} from '../services/api';

export default function AttendancePage() {
  const { user } = useAuth();
  const isStudent = user?.role === 'student';

  // Shared state
  const [subjects, setSubjects] = useState([]);
  const [students, setStudents] = useState([]);
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [attendance, setAttendance] = useState([]);   // existing records
  const [records, setRecords] = useState([]);          // for marking (lecturer/admin)
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');

  // Student-specific
  const [studentProfile, setStudentProfile] = useState(null);
  const [studentData, setStudentData] = useState({ data: [], summary: [] });

  useEffect(() => {
    if (!isStudent) {
      Promise.all([getSubjects(), getStudents()])
        .then(([s, st]) => {
          setSubjects(s.data.data);
          setStudents(st.data.data);
        });
    }
  }, []);

  // Load student's own attendance
  useEffect(() => {
    if (isStudent) {
      // Get student profile from localStorage
      const u = JSON.parse(localStorage.getItem('learnify_user') || '{}');
      const profile = u.profile;
      if (profile) {
        setStudentProfile(profile);
        setLoading(true);
        getStudentAttendance(profile.id)
          .then(r => setStudentData({ data: r.data.data, summary: r.data.summary }))
          .finally(() => setLoading(false));
      }
    }
  }, []);

  // Load attendance records for selected subject/date (lecturer/admin)
  useEffect(() => {
    if (!isStudent && selectedSubject) {
      setLoading(true);
      Promise.all([
        getAttendanceBySubject(selectedSubject, selectedDate),
      ]).then(([r]) => {
        setAttendance(r.data.data);
        // Init records with existing data or default absent
        const existingMap = {};
        r.data.data.forEach(a => { existingMap[a.student_id] = a.status; });
        setRecords(students.map(s => ({ student_id: s.id, name: s.name, college_id: s.college_id, status: existingMap[s.id] || 'absent' })));
      }).finally(() => setLoading(false));
    }
  }, [selectedSubject, selectedDate, students]);

  const handleToggle = (studentId) => {
    setRecords(prev => prev.map(r =>
      r.student_id === studentId ? { ...r, status: r.status === 'present' ? 'absent' : 'present' } : r
    ));
  };

  const handleMarkAll = (status) => {
    setRecords(prev => prev.map(r => ({ ...r, status })));
  };

  const handleSave = async () => {
    if (!selectedSubject) return;
    setSaving(true); setMsg('');
    try {
      await markAttendance({ subject_id: selectedSubject, date: selectedDate, records });
      setMsg('✅ Attendance saved successfully!');
    } catch (err) {
      setMsg('❌ Failed to save attendance.');
    } finally { setSaving(false); }
  };

  const presentCount = records.filter(r => r.status === 'present').length;

  // ---- STUDENT VIEW ----
  if (isStudent) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="font-display font-bold text-2xl text-gray-900">My Attendance</h2>
          <p className="text-gray-500 text-sm mt-1">Your attendance records across all subjects</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {studentData.summary.map((s, i) => {
            const pct = parseFloat(s.percentage) || 0;
            const color = pct >= 75 ? 'border-green-200 bg-green-50' : pct >= 50 ? 'border-yellow-200 bg-yellow-50' : 'border-red-200 bg-red-50';
            const textColor = pct >= 75 ? 'text-green-700' : pct >= 50 ? 'text-yellow-600' : 'text-red-600';
            return (
              <div key={i} className={`card border-2 ${color}`}>
                <h4 className="font-semibold text-gray-800 text-sm">{s.subject_name}</h4>
                <div className="flex items-end justify-between mt-3">
                  <div>
                    <p className="text-xs text-gray-500">Present: {s.present} / {s.total}</p>
                    <p className="text-xs text-gray-500">Absent: {s.absent}</p>
                  </div>
                  <p className={`text-3xl font-bold font-display ${textColor}`}>{pct}%</p>
                </div>
                <div className="mt-3 bg-gray-200 rounded-full h-1.5">
                  <div className={`h-1.5 rounded-full transition-all ${pct >= 75 ? 'bg-green-500' : pct >= 50 ? 'bg-yellow-400' : 'bg-red-400'}`}
                    style={{ width: `${Math.min(pct, 100)}%` }} />
                </div>
              </div>
            );
          })}
        </div>

        {/* Attendance Log */}
        <div className="card">
          <h3 className="font-display font-semibold text-gray-900 mb-4">Attendance Log</h3>
          {loading ? (
            <div className="flex justify-center py-8"><div className="animate-spin w-8 h-8 border-4 border-primary-600 border-t-transparent rounded-full" /></div>
          ) : studentData.data.length === 0 ? (
            <p className="text-gray-400 text-sm text-center py-8">No attendance records found.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr>
                    {['Date', 'Subject', 'Course', 'Status'].map(h => <th key={h} className="table-header">{h}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {studentData.data.map((a, i) => (
                    <tr key={i} className="hover:bg-gray-50">
                      <td className="table-cell">{new Date(a.date).toLocaleDateString()}</td>
                      <td className="table-cell font-medium">{a.subject_name}</td>
                      <td className="table-cell text-gray-500">{a.course_name}</td>
                      <td className="table-cell">
                        <span className={a.status === 'present' ? 'badge-success' : 'badge-danger'}>
                          {a.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ---- LECTURER / ADMIN VIEW ----
  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display font-bold text-2xl text-gray-900">Attendance Management</h2>
        <p className="text-gray-500 text-sm mt-1">Mark and manage student attendance</p>
      </div>

      {/* Filters */}
      <div className="card">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="label">Select Subject</label>
            <select className="input-field" value={selectedSubject} onChange={e => setSelectedSubject(e.target.value)}>
              <option value="">-- Choose Subject --</option>
              {subjects.map(s => <option key={s.id} value={s.id}>{s.subject_name} ({s.course_name})</option>)}
            </select>
          </div>
          <div>
            <label className="label">Date</label>
            <input type="date" className="input-field" value={selectedDate}
              onChange={e => setSelectedDate(e.target.value)} max={new Date().toISOString().split('T')[0]} />
          </div>
        </div>
      </div>

      {selectedSubject && (
        <div className="card">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
            <div>
              <h3 className="font-display font-semibold text-gray-900">Mark Attendance</h3>
              <p className="text-sm text-gray-500">{presentCount} / {records.length} present</p>
            </div>
            <div className="flex gap-2">
              <button onClick={() => handleMarkAll('present')} className="btn-secondary text-xs text-green-700 border-green-200">
                Mark All Present
              </button>
              <button onClick={() => handleMarkAll('absent')} className="btn-secondary text-xs text-red-700 border-red-200">
                Mark All Absent
              </button>
            </div>
          </div>

          {loading ? (
            <div className="flex justify-center py-8"><div className="animate-spin w-8 h-8 border-4 border-primary-600 border-t-transparent rounded-full" /></div>
          ) : records.length === 0 ? (
            <p className="text-gray-400 text-sm text-center py-8">No students found.</p>
          ) : (
            <div className="space-y-2">
              {records.map(r => (
                <div key={r.student_id}
                  className={`flex items-center justify-between p-3 rounded-xl border-2 cursor-pointer transition-all ${r.status === 'present' ? 'border-green-200 bg-green-50' : 'border-gray-100 bg-white hover:border-gray-200'}`}
                  onClick={() => handleToggle(r.student_id)}>
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${r.status === 'present' ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-500'}`}>
                      {r.name?.charAt(0)}
                    </div>
                    <div>
                      <p className="font-medium text-sm text-gray-800">{r.name}</p>
                      <p className="text-xs text-gray-400">{r.college_id}</p>
                    </div>
                  </div>
                  <span className={r.status === 'present' ? 'badge-success' : 'badge-danger'}>{r.status}</span>
                </div>
              ))}
            </div>
          )}

          {msg && <p className="mt-4 text-sm font-medium">{msg}</p>}

          <div className="mt-4 flex justify-end">
            <button onClick={handleSave} className="btn-primary px-8" disabled={saving || records.length === 0}>
              {saving ? 'Saving...' : 'Save Attendance'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
