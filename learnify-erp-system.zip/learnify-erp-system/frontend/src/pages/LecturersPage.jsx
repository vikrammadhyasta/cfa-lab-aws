import { useEffect, useState } from 'react';
import { getLecturers, deleteLecturer, register } from '../services/api';
import DataTable from '../components/common/DataTable';
import Modal from '../components/common/Modal';

export default function LecturersPage() {
  const [lecturers, setLecturers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ name:'', email:'', password:'', role:'lecturer', department:'', employee_id:'' });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const load = () => {
    setLoading(true);
    getLecturers().then(r => setLecturers(r.data.data)).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const handleDelete = async (id) => {
    if (!confirm('Delete this lecturer?')) return;
    await deleteLecturer(id);
    load();
  };

  const handleAdd = async (e) => {
    e.preventDefault(); setError(''); setSubmitting(true);
    try {
      await register(form);
      setShowAdd(false);
      setForm({ name:'', email:'', password:'', role:'lecturer', department:'', employee_id:'' });
      load();
    } catch(err) { setError(err.response?.data?.message || 'Failed to add lecturer.'); }
    finally { setSubmitting(false); }
  };

  const filtered = lecturers.filter(l =>
    l.name?.toLowerCase().includes(search.toLowerCase()) ||
    l.employee_id?.toLowerCase().includes(search.toLowerCase()) ||
    l.department?.toLowerCase().includes(search.toLowerCase())
  );

  const columns = [
    { key: 'name', label: 'Name', render: v => <span className="font-medium">{v}</span> },
    { key: 'email', label: 'Email' },
    { key: 'employee_id', label: 'Employee ID', render: v => <span className="badge-warning">{v}</span> },
    { key: 'department', label: 'Department' },
    { key: 'id', label: 'Actions', render: (_, row) => (
      <button onClick={() => handleDelete(row.id)} className="text-red-500 hover:text-red-700 text-xs font-medium">Delete</button>
    )}
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display font-bold text-2xl text-gray-900">Lecturers</h2>
          <p className="text-gray-500 text-sm mt-1">{lecturers.length} faculty members</p>
        </div>
        <button onClick={() => setShowAdd(true)} className="btn-primary flex items-center gap-2">
          <span>+</span> Add Lecturer
        </button>
      </div>

      <div className="card">
        <div className="mb-4">
          <input className="input-field max-w-sm" placeholder="Search by name, ID or department..." value={search}
            onChange={e => setSearch(e.target.value)} />
        </div>
        <DataTable columns={columns} data={filtered} loading={loading} emptyMessage="No lecturers found." />
      </div>

      <Modal isOpen={showAdd} onClose={() => setShowAdd(false)} title="Add New Lecturer">
        <form onSubmit={handleAdd} className="space-y-4">
          {error && <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg">{error}</div>}
          <div>
            <label className="label">Full Name</label>
            <input className="input-field" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required />
          </div>
          <div>
            <label className="label">Email</label>
            <input type="email" className="input-field" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} required />
          </div>
          <div>
            <label className="label">Password</label>
            <input type="password" className="input-field" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} required minLength={6} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Employee ID</label>
              <input className="input-field" value={form.employee_id} onChange={e=>setForm({...form,employee_id:e.target.value})} required />
            </div>
            <div>
              <label className="label">Department</label>
              <input className="input-field" value={form.department} onChange={e=>setForm({...form,department:e.target.value})} required />
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <button type="submit" className="btn-primary flex-1" disabled={submitting}>{submitting ? 'Adding...' : 'Add Lecturer'}</button>
            <button type="button" className="btn-secondary flex-1" onClick={() => setShowAdd(false)}>Cancel</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
