import { useEffect, useState } from 'react';
import { getStudentDashboard } from '../services/api';
import StatCard from '../components/common/StatCard';
import { useAuth } from '../components/AuthContext';
import { RadialBarChart, RadialBar, ResponsiveContainer, Tooltip } from 'recharts';

export default function StudentDashboard() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getStudentDashboard()
      .then(res => setData(res.data.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="flex justify-center py-20">
      <div className="animate-spin w-10 h-10 border-4 border-primary-600 border-t-transparent rounded-full" />
    </div>
  );

  const { student, stats = {}, recentMarks = [], subjects = [] } = data || {};
  const attPct = parseFloat(stats.attendance_pct) || 0;
  const attColor = attPct >= 75 ? 'text-green-600' : attPct >= 50 ? 'text-yellow-500' : 'text-red-500';

  const examBadge = (type) => {
    const map = { internal: 'badge-info', midterm: 'badge-warning', final: 'badge-danger', assignment: 'badge-success' };
    return map[type] || 'badge-info';
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h2 className="font-display font-bold text-2xl text-gray-900">Hello, {user?.name} 👋</h2>
          <p className="text-gray-500 text-sm mt-1">
            {student?.department} · Semester {student?.semester} · 
            <span className="badge-info ml-2">{student?.college_id}</span>
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Classes" value={stats.total_classes ?? 0} icon="📅" color="primary" />
        <StatCard title="Present" value={stats.present ?? 0} icon="✅" color="green" />
        <StatCard title="Absent" value={stats.absent ?? 0} icon="❌" color="red" />
        <div className="card flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-purple-50 flex items-center justify-center flex-shrink-0">
            <span className="text-xl">📊</span>
          </div>
          <div>
            <p className="text-sm text-gray-500 font-medium">Attendance</p>
            <p className={`text-2xl font-bold font-display ${attColor}`}>{attPct}%</p>
            <p className="text-xs text-gray-400">{attPct >= 75 ? '✓ Good standing' : '⚠ Below 75%'}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Marks */}
        <div className="card">
          <h3 className="font-display font-semibold text-gray-900 mb-4">Recent Marks</h3>
          {recentMarks.length === 0 ? (
            <p className="text-gray-400 text-sm text-center py-8">No marks available yet.</p>
          ) : (
            <div className="space-y-3">
              {recentMarks.map((m, i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                  <div>
                    <p className="font-medium text-sm text-gray-800">{m.subject_name}</p>
                    <span className={`text-xs mt-1 ${examBadge(m.exam_type)}`}>{m.exam_type}</span>
                  </div>
                  <div className={`text-2xl font-bold font-display ${m.marks >= 75 ? 'text-green-600' : m.marks >= 50 ? 'text-yellow-500' : 'text-red-500'}`}>
                    {m.marks}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Subjects */}
        <div className="card">
          <h3 className="font-display font-semibold text-gray-900 mb-4">My Subjects</h3>
          {subjects.length === 0 ? (
            <p className="text-gray-400 text-sm text-center py-8">No subjects found for your department.</p>
          ) : (
            <div className="space-y-2">
              {subjects.slice(0, 6).map(s => (
                <div key={s.id} className="flex items-center justify-between p-3 border border-gray-100 rounded-xl hover:border-primary-200 transition-colors">
                  <div>
                    <p className="font-medium text-sm text-gray-800">{s.subject_name}</p>
                    <p className="text-xs text-gray-400">{s.course_name}</p>
                  </div>
                  <p className="text-xs text-gray-500">{s.lecturer_name || 'TBA'}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
