import { useEffect, useState } from 'react';
import { getLecturerDashboard } from '../services/api';
import StatCard from '../components/common/StatCard';
import { useAuth } from '../components/AuthContext';

export default function LecturerDashboard() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getLecturerDashboard()
      .then(res => setData(res.data.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="flex justify-center py-20">
      <div className="animate-spin w-10 h-10 border-4 border-primary-600 border-t-transparent rounded-full" />
    </div>
  );

  const { subjects = [], stats = {} } = data || {};

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display font-bold text-2xl text-gray-900">Welcome, {user?.name} 👋</h2>
        <p className="text-gray-500 text-sm mt-1">Here's your teaching overview for today.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <StatCard title="Subjects Assigned" value={stats.subjects ?? 0} icon="📚" color="primary" />
        <StatCard title="Marks Entered" value={stats.total_marks ?? 0} icon="📝" color="green" />
      </div>

      <div className="card">
        <h3 className="font-display font-semibold text-gray-900 mb-4">Your Subjects</h3>
        {subjects.length === 0 ? (
          <p className="text-gray-400 text-sm text-center py-8">No subjects assigned yet.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {subjects.map(s => (
              <div key={s.id} className="border border-gray-100 rounded-xl p-4 hover:border-primary-200 hover:bg-primary-50/30 transition-all">
                <h4 className="font-semibold text-gray-800">{s.subject_name}</h4>
                <p className="text-sm text-gray-500 mt-1">{s.course_name}</p>
                <div className="flex items-center justify-between mt-3">
                  <span className="badge-info">{s.department}</span>
                  <span className="text-xs text-gray-400">👥 {s.student_count} students</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
