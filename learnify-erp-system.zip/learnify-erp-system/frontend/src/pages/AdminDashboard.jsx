import { useEffect, useState } from 'react';
import { getAdminDashboard } from '../services/api';
import StatCard from '../components/common/StatCard';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];

export default function AdminDashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getAdminDashboard()
      .then(res => setData(res.data.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="flex justify-center py-20">
      <div className="animate-spin w-10 h-10 border-4 border-primary-600 border-t-transparent rounded-full" />
    </div>
  );

  const { stats, recentStudents, deptDistribution } = data || {};

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display font-bold text-2xl text-gray-900">Admin Dashboard</h2>
        <p className="text-gray-500 text-sm mt-1">Welcome back! Here's an overview of your institution.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        <StatCard title="Total Students" value={stats?.students ?? 0} icon="🎓" color="primary" />
        <StatCard title="Lecturers" value={stats?.lecturers ?? 0} icon="👨‍🏫" color="blue" />
        <StatCard title="Courses" value={stats?.courses ?? 0} icon="📚" color="green" />
        <StatCard title="Subjects" value={stats?.subjects ?? 0} icon="📖" color="orange" />
        <StatCard title="Attendance %" value={`${stats?.attendance_pct ?? 0}%`} icon="📋" color="purple" subtitle="Overall" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Department Distribution */}
        <div className="card">
          <h3 className="font-display font-semibold text-gray-900 mb-4">Students by Department</h3>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={deptDistribution} dataKey="count" nameKey="department" cx="50%" cy="50%" outerRadius={80} label>
                {(deptDistribution || []).map((_, i) => (
                  <Cell key={i} fill={COLORS[i % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Bar chart of depts */}
        <div className="card">
          <h3 className="font-display font-semibold text-gray-900 mb-4">Student Count per Department</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={deptDistribution} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="department" tick={{ fontSize: 11 }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="count" fill="#6366f1" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Students */}
      <div className="card">
        <h3 className="font-display font-semibold text-gray-900 mb-4">Recently Enrolled Students</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr>
                {['Name', 'College ID', 'Department', 'Semester', 'Joined'].map(h => (
                  <th key={h} className="table-header">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(recentStudents || []).map((s, i) => (
                <tr key={i} className="hover:bg-gray-50">
                  <td className="table-cell font-medium">{s.name}</td>
                  <td className="table-cell"><span className="badge-info">{s.college_id}</span></td>
                  <td className="table-cell">{s.department}</td>
                  <td className="table-cell">Sem {s.semester}</td>
                  <td className="table-cell text-gray-400">{new Date(s.created_at).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
