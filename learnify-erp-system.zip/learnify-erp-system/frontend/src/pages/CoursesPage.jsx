import { useEffect, useState } from 'react';
import { getCourses, createCourse, deleteCourse, getSubjects, createSubject, deleteSubject, getLecturers } from '../services/api';
import DataTable from '../components/common/DataTable';
import Modal from '../components/common/Modal';

export default function CoursesPage() {
  const [courses, setCourses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [lecturers, setLecturers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('courses');
  const [showModal, setShowModal] = useState(false);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [courseForm, setCourseForm] = useState({ course_name: '', department: '' });
  const [subjectForm, setSubjectForm] = useState({ subject_name: '', course_id: '', lecturer_id: '' });

  const load = () => {
    setLoading(true);
    Promise.all([getCourses(), getSubjects(), getLecturers()])
      .then(([c, s, l]) => {
        setCourses(c.data.data);
        setSubjects(s.data.data);
        setLecturers(l.data.data);
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const handleAddCourse = async (e) => {
    e.preventDefault(); setError(''); setSubmitting(true);
    try {
      await createCourse(courseForm);
      setShowModal(false);
      setCourseForm({ course_name: '', department: '' });
      load();
    } catch(err) { setError(err.response?.data?.message || 'Failed.'); }
    finally { setSubmitting(false); }
  };

  const handleAddSubject = async (e) => {
    e.preventDefault(); setError(''); setSubmitting(true);
    try {
      await createSubject(subjectForm);
      setShowModal(false);
      setSubjectForm({ subject_name: '', course_id: '', lecturer_id: '' });
      load();
    } catch(err) { setError(err.response?.data?.message || 'Failed.'); }
    finally { setSubmitting(false); }
  };

  const courseColumns = [
    { key: 'course_name', label: 'Course Name', render: v => <span className="font-medium">{v}</span> },
    { key: 'department', label: 'Department' },
    { key: 'id', label: 'Actions', render: (_, row) => (
      <button onClick={async () => { if(confirm('Delete course?')) { await deleteCourse(row.id); load(); }}}
        className="text-red-500 hover:text-red-700 text-xs font-medium">Delete</button>
    )}
  ];

  const subjectColumns = [
    { key: 'subject_name', label: 'Subject Name', render: v => <span className="font-medium">{v}</span> },
    { key: 'course_name', label: 'Course' },
    { key: 'department', label: 'Department' },
    { key: 'lecturer_name', label: 'Lecturer', render: v => v || <span className="text-gray-400">Unassigned</span> },
    { key: 'id', label: 'Actions', render: (_, row) => (
      <button onClick={async () => { if(confirm('Delete subject?')) { await deleteSubject(row.id); load(); }}}
        className="text-red-500 hover:text-red-700 text-xs font-medium">Delete</button>
    )}
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display font-bold text-2xl text-gray-900">Courses & Subjects</h2>
          <p className="text-gray-500 text-sm mt-1">{courses.length} courses · {subjects.length} subjects</p>
        </div>
        <button onClick={() => { setError(''); setShowModal(true); }} className="btn-primary flex items-center gap-2">
          <span>+</span> Add {tab === 'courses' ? 'Course' : 'Subject'}
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        {['courses', 'subjects'].map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-5 py-2 rounded-xl text-sm font-medium transition-all capitalize ${tab === t ? 'bg-primary-600 text-white shadow-md shadow-primary-200' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
            {t} ({t === 'courses' ? courses.length : subjects.length})
          </button>
        ))}
      </div>

      <div className="card">
        {tab === 'courses'
          ? <DataTable columns={courseColumns} data={courses} loading={loading} emptyMessage="No courses found." />
          : <DataTable columns={subjectColumns} data={subjects} loading={loading} emptyMessage="No subjects found." />
        }
      </div>

      {/* Add Modal */}
      <Modal isOpen={showModal} onClose={() => setShowModal(false)} title={`Add ${tab === 'courses' ? 'Course' : 'Subject'}`}>
        {tab === 'courses' ? (
          <form onSubmit={handleAddCourse} className="space-y-4">
            {error && <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg">{error}</div>}
            <div>
              <label className="label">Course Name</label>
              <input className="input-field" value={courseForm.course_name}
                onChange={e => setCourseForm({...courseForm, course_name: e.target.value})} required />
            </div>
            <div>
              <label className="label">Department</label>
              <input className="input-field" value={courseForm.department}
                onChange={e => setCourseForm({...courseForm, department: e.target.value})} required />
            </div>
            <div className="flex gap-3 pt-2">
              <button type="submit" className="btn-primary flex-1" disabled={submitting}>{submitting ? 'Adding...' : 'Add Course'}</button>
              <button type="button" className="btn-secondary flex-1" onClick={() => setShowModal(false)}>Cancel</button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleAddSubject} className="space-y-4">
            {error && <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg">{error}</div>}
            <div>
              <label className="label">Subject Name</label>
              <input className="input-field" value={subjectForm.subject_name}
                onChange={e => setSubjectForm({...subjectForm, subject_name: e.target.value})} required />
            </div>
            <div>
              <label className="label">Course</label>
              <select className="input-field" value={subjectForm.course_id}
                onChange={e => setSubjectForm({...subjectForm, course_id: e.target.value})} required>
                <option value="">Select Course</option>
                {courses.map(c => <option key={c.id} value={c.id}>{c.course_name}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Assign Lecturer (optional)</label>
              <select className="input-field" value={subjectForm.lecturer_id}
                onChange={e => setSubjectForm({...subjectForm, lecturer_id: e.target.value})}>
                <option value="">Unassigned</option>
                {lecturers.map(l => <option key={l.id} value={l.id}>{l.name} — {l.department}</option>)}
              </select>
            </div>
            <div className="flex gap-3 pt-2">
              <button type="submit" className="btn-primary flex-1" disabled={submitting}>{submitting ? 'Adding...' : 'Add Subject'}</button>
              <button type="button" className="btn-secondary flex-1" onClick={() => setShowModal(false)}>Cancel</button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
}
