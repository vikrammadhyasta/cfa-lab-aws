import { useEffect, useState } from 'react';
import { useAuth } from '../components/AuthContext';
import { getSubjects, getStudents, addMarks, getMarksBySubject, getStudentMarks, deleteMarks } from '../services/api';
import Modal from '../components/common/Modal';

const EXAM_TYPES = ['internal', 'midterm', 'final', 'assignment'];
const examBadge = { internal: 'badge-info', midterm: 'badge-warning', final: 'badge-danger', assignment: 'badge-success' };

export default function MarksPage() {
  const { user } = useAuth();
  const isStudent = user?.role === 'student';

  const [subjects, setSubjects] = useState([]);
  const [students, setStudents] = useState([]);
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedExamType, setSelectedExamType] = useState('');
  const [marks, setMarks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ student_id: '', subject_id: '', marks: '', exam_type: 'internal' });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [msg, setMsg] = useState('');

  // Student-specific
  const [studentMarks, setStudentMarks] = useState({ data: [], summary: [] });

  useEffect(() => {
    if (!isStudent) {
      Promise.all([getSubjects(), getStudents()])
        .then(([s, st]) => { setSubjects(s.data.data); setStudents(st.data.data); });
    } else {
      const u = JSON.parse(localStorage.getItem('learnify_user') || '{}');
      const profile = u.profile;
      if (profile) {
        setLoading(true);
        getStudentMarks(profile.id)
          .then(r => setStudentMarks({ data: r.data.data, summary: r.data.summary }))
          .finally(() => setLoading(false));
      }
    }
  }, []);

  useEffect(() => {
    if (!isStudent && selectedSubject) {
      setLoading(true);
      getMarksBySubject(selectedSubject, selectedExamType)
        .then(r => setMarks(r.data.data))
        .finally(() => setLoading(false));
    }
  }, [selectedSubject, selectedExamType]);

  const handleAdd = async (e) => {
    e.preventDefault(); setError(''); setSubmitting(true);
    try {
      await addMarks(form);
      setShowAdd(false);
      setForm({ student_id: '', subject_id: '', marks: '', exam_type: 'internal' });
      setMsg('✅ Marks added successfully!');
      if (selectedSubject) {
        const r = await getMarksBySubject(selectedSubject, selectedExamType);
        setMarks(r.data.data);
      }
    } catch(err) { setError(err.response?.data?.message || 'Failed to add marks.'); }
    finally { setSubmitting(false); }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this mark entry?')) return;
    await deleteMarks(id);
    const r = await getMarksBySubject(selectedSubject, selectedExamType);
    setMarks(r.data.data);
  };

  const gradeColor = (m) => {
    if (m >= 90) return 'text-green-600';
    if (m >= 75) return 'text-blue-600';
    if (m >= 50) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getGrade = (m) => {
    if (m >= 90) return 'A+';
    if (m >= 80) return 'A';
    if (m >= 70) return 'B';
    if (m >= 60) return 'C';
    if (m >= 50) return 'D';
    return 'F';
  };

  // ---- STUDENT VIEW ----
  if (isStudent) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="font-display font-bold text-2xl text-gray-900">My Marks</h2>
          <p className="text-gray-500 text-sm mt-1">Your academic performance records</p>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {studentMarks.summary.map((s, i) => (
            <div key={i} className="card border border-gray-100">
              <h4 className="font-semibold text-gray-800 text-sm">{s.subject_name}</h4>
              <p className="text-xs text-gray-500 mt-1 capitalize">{s.exam_type}</p>
              <div className="flex items-end justify-between mt-3">
                <div>
                  <p className="text-xs text-gray-400">Highest: <span className="text-green-600 font-semibold">{s.highest}</span></p>
                  <p className="text-xs text-gray-400">Lowest: <span className="text-red-500 font-semibold">{s.lowest}</span></p>
                </div>
                <div className="text-right">
                  <p className={`text-3xl font-bold font-display ${gradeColor(s.average)}`}>{parseFloat(s.average).toFixed(1)}</p>
                  <p className="text-xs text-gray-400">avg</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Marks Table */}
        <div className="card">
          <h3 className="font-display font-semibold text-gray-900 mb-4">Marks Detail</h3>
          {loading ? (
            <div className="flex justify-center py-8"><div className="animate-spin w-8 h-8 border-4 border-primary-600 border-t-transparent rounded-full" /></div>
          ) : studentMarks.data.length === 0 ? (
            <p className="text-gray-400 text-sm text-center py-8">No marks found.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr>{['Subject','Course','Exam Type','Marks','Grade','Date'].map(h=><th key={h} className="table-header">{h}</th>)}</tr>
                </thead>
                <tbody>
                  {studentMarks.data.map((m, i) => (
                    <tr key={i} className="hover:bg-gray-50">
                      <td className="table-cell font-medium">{m.subject_name}</td>
                      <td className="table-cell text-gray-500">{m.course_name}</td>
                      <td className="table-cell"><span className={examBadge[m.exam_type]}>{m.exam_type}</span></td>
                      <td className="table-cell"><span className={`text-xl font-bold font-display ${gradeColor(m.marks)}`}>{m.marks}</span></td>
                      <td className="table-cell"><span className={`font-bold ${gradeColor(m.marks)}`}>{getGrade(m.marks)}</span></td>
                      <td className="table-cell text-gray-400">{new Date(m.created_at).toLocaleDateString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ---- LECTURER / ADMIN VIEW ----
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display font-bold text-2xl text-gray-900">Marks Management</h2>
          <p className="text-gray-500 text-sm mt-1">Enter and manage student marks</p>
        </div>
        <button onClick={() => { setError(''); setShowAdd(true); }} className="btn-primary flex items-center gap-2">
          <span>+</span> Add Marks
        </button>
      </div>

      {/* Filters */}
      <div className="card">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="label">Subject</label>
            <select className="input-field" value={selectedSubject} onChange={e => setSelectedSubject(e.target.value)}>
              <option value="">-- Choose Subject --</option>
              {subjects.map(s => <option key={s.id} value={s.id}>{s.subject_name} ({s.course_name})</option>)}
            </select>
          </div>
          <div>
            <label className="label">Exam Type (optional filter)</label>
            <select className="input-field" value={selectedExamType} onChange={e => setSelectedExamType(e.target.value)}>
              <option value="">All Types</option>
              {EXAM_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
        </div>
      </div>

      {msg && <p className="text-sm font-medium text-green-600 bg-green-50 border border-green-200 px-4 py-2 rounded-lg">{msg}</p>}

      {selectedSubject && (
        <div className="card">
          <h3 className="font-display font-semibold text-gray-900 mb-4">
            Marks Records {marks.length > 0 && `(${marks.length})`}
          </h3>
          {loading ? (
            <div className="flex justify-center py-8"><div className="animate-spin w-8 h-8 border-4 border-primary-600 border-t-transparent rounded-full" /></div>
          ) : marks.length === 0 ? (
            <p className="text-gray-400 text-sm text-center py-8">No marks found for selected filters.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr>{['Student','College ID','Exam Type','Marks','Grade','Date','Actions'].map(h=><th key={h} className="table-header">{h}</th>)}</tr>
                </thead>
                <tbody>
                  {marks.map((m, i) => (
                    <tr key={i} className="hover:bg-gray-50">
                      <td className="table-cell font-medium">{m.student_name}</td>
                      <td className="table-cell"><span className="badge-info">{m.college_id}</span></td>
                      <td className="table-cell"><span className={examBadge[m.exam_type]}>{m.exam_type}</span></td>
                      <td className="table-cell"><span className={`text-xl font-bold font-display ${gradeColor(m.marks)}`}>{m.marks}</span></td>
                      <td className="table-cell"><span className={`font-bold ${gradeColor(m.marks)}`}>{getGrade(m.marks)}</span></td>
                      <td className="table-cell text-gray-400">{new Date(m.created_at).toLocaleDateString()}</td>
                      <td className="table-cell">
                        {user?.role === 'admin' && (
                          <button onClick={() => handleDelete(m.id)} className="text-red-500 hover:text-red-700 text-xs font-medium">Delete</button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      <Modal isOpen={showAdd} onClose={() => setShowAdd(false)} title="Add Marks">
        <form onSubmit={handleAdd} className="space-y-4">
          {error && <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg">{error}</div>}
          <div>
            <label className="label">Student</label>
            <select className="input-field" value={form.student_id} onChange={e => setForm({...form, student_id: e.target.value})} required>
              <option value="">Select Student</option>
              {students.map(s => <option key={s.id} value={s.id}>{s.name} — {s.college_id}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Subject</label>
            <select className="input-field" value={form.subject_id} onChange={e => setForm({...form, subject_id: e.target.value})} required>
              <option value="">Select Subject</option>
              {subjects.map(s => <option key={s.id} value={s.id}>{s.subject_name}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Marks (out of 100)</label>
              <input type="number" min="0" max="100" step="0.5" className="input-field" value={form.marks}
                onChange={e => setForm({...form, marks: e.target.value})} required />
            </div>
            <div>
              <label className="label">Exam Type</label>
              <select className="input-field" value={form.exam_type} onChange={e => setForm({...form, exam_type: e.target.value})}>
                {EXAM_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <button type="submit" className="btn-primary flex-1" disabled={submitting}>{submitting ? 'Saving...' : 'Save Marks'}</button>
            <button type="button" className="btn-secondary flex-1" onClick={() => setShowAdd(false)}>Cancel</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
