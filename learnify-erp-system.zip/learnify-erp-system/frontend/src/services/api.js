import axios from 'axios';

// In dev: Vite proxy forwards /api → http://localhost:5000
// In production: set VITE_API_URL=https://your-backend.com in frontend .env
const BASE_URL = import.meta.env.VITE_API_URL
  ? `${import.meta.env.VITE_API_URL}/api`
  : '/api';

const API = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' }
});

// Attach token to every request
API.interceptors.request.use(config => {
  const token = localStorage.getItem('learnify_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Handle 401 globally
API.interceptors.response.use(
  res => res,
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('learnify_token');
      localStorage.removeItem('learnify_user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

// ---- Auth ----
export const login = (data) => API.post('/auth/login', data);
export const register = (data) => API.post('/auth/register', data);
export const getMe = () => API.get('/auth/me');

// ---- Dashboard ----
export const getAdminDashboard = () => API.get('/dashboard/admin');
export const getLecturerDashboard = () => API.get('/dashboard/lecturer');
export const getStudentDashboard = () => API.get('/dashboard/student');

// ---- Students ----
export const getStudents = () => API.get('/students');
export const getStudentById = (id) => API.get(`/students/${id}`);
export const updateStudent = (id, data) => API.put(`/students/${id}`, data);
export const deleteStudent = (id) => API.delete(`/students/${id}`);

// ---- Lecturers ----
export const getLecturers = () => API.get('/lecturers');
export const getLecturerById = (id) => API.get(`/lecturers/${id}`);
export const getLecturerSubjects = (id) => API.get(`/lecturers/${id}/subjects`);
export const deleteLecturer = (id) => API.delete(`/lecturers/${id}`);

// ---- Courses ----
export const getCourses = () => API.get('/courses');
export const createCourse = (data) => API.post('/courses', data);
export const updateCourse = (id, data) => API.put(`/courses/${id}`, data);
export const deleteCourse = (id) => API.delete(`/courses/${id}`);

// ---- Subjects ----
export const getSubjects = () => API.get('/subjects');
export const createSubject = (data) => API.post('/subjects', data);
export const updateSubject = (id, data) => API.put(`/subjects/${id}`, data);
export const deleteSubject = (id) => API.delete(`/subjects/${id}`);

// ---- Attendance ----
export const markAttendance = (data) => API.post('/attendance', data);
export const getAttendanceBySubject = (subjectId, date) =>
  API.get(`/attendance/subject/${subjectId}${date ? `?date=${date}` : ''}`);
export const getStudentAttendance = (studentId) => API.get(`/attendance/student/${studentId}`);

// ---- Marks ----
export const addMarks = (data) => API.post('/marks', data);
export const updateMarks = (id, data) => API.put(`/marks/${id}`, data);
export const deleteMarks = (id) => API.delete(`/marks/${id}`);
export const getStudentMarks = (studentId) => API.get(`/marks/student/${studentId}`);
export const getMarksBySubject = (subjectId, examType) =>
  API.get(`/marks/subject/${subjectId}${examType ? `?exam_type=${examType}` : ''}`);

export default API;
