# 🎓 Learnify ERP System

A full-stack Academic ERP (Enterprise Resource Planning) System built for college management. Designed as a final-year BCA/MCA project demonstration.

---

## 🛠 Tech Stack

| Layer        | Technology                          |
|--------------|-------------------------------------|
| Frontend     | React 18 + Vite + Tailwind CSS      |
| Backend      | Node.js + Express.js                |
| Database     | MySQL                               |
| Auth         | JWT (JSON Web Tokens)               |
| HTTP Client  | Axios                               |
| Charts       | Recharts                            |

---

## 📁 Project Structure

```
learnify-erp-system/
│
├── backend/
│   ├── config/
│   │   ├── db.js             # MySQL connection pool
│   │   └── schema.sql        # Database schema + seed data
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── studentController.js
│   │   ├── lecturerController.js
│   │   ├── courseController.js
│   │   ├── attendanceController.js
│   │   ├── marksController.js
│   │   └── dashboardController.js
│   ├── middleware/
│   │   ├── auth.js           # JWT + role-based middleware
│   │   └── errorHandler.js
│   ├── routes/
│   │   ├── authRoutes.js
│   │   ├── studentRoutes.js
│   │   ├── lecturerRoutes.js
│   │   ├── courseRoutes.js
│   │   ├── attendanceRoutes.js
│   │   ├── marksRoutes.js
│   │   └── dashboardRoutes.js
│   ├── server.js
│   ├── .env.example
│   └── package.json
│
└── frontend/
    ├── src/
    │   ├── components/
    │   │   ├── AuthContext.jsx        # Global auth state
    │   │   └── common/
    │   │       ├── StatCard.jsx
    │   │       ├── DataTable.jsx
    │   │       └── Modal.jsx
    │   ├── layouts/
    │   │   └── DashboardLayout.jsx   # Sidebar + Navbar
    │   ├── pages/
    │   │   ├── LoginPage.jsx
    │   │   ├── RegisterPage.jsx
    │   │   ├── AdminDashboard.jsx
    │   │   ├── LecturerDashboard.jsx
    │   │   ├── StudentDashboard.jsx
    │   │   ├── StudentsPage.jsx
    │   │   ├── LecturersPage.jsx
    │   │   ├── CoursesPage.jsx
    │   │   ├── AttendancePage.jsx
    │   │   └── MarksPage.jsx
    │   ├── services/
    │   │   └── api.js                # Axios API service
    │   ├── App.jsx
    │   ├── main.jsx
    │   └── index.css
    ├── index.html
    ├── vite.config.js
    ├── tailwind.config.js
    └── package.json
```

---

## 🗄 Database Schema

### Tables

| Table        | Key Fields                                             |
|--------------|--------------------------------------------------------|
| `users`      | id, name, email, password, role                        |
| `students`   | id, user_id, department, semester, college_id          |
| `lecturers`  | id, user_id, department, employee_id                   |
| `courses`    | id, course_name, department                            |
| `subjects`   | id, subject_name, course_id, lecturer_id               |
| `attendance` | id, student_id, subject_id, date, status               |
| `marks`      | id, student_id, subject_id, marks, exam_type           |

---

## 🔐 Roles & Access

| Feature              | Admin | Lecturer | Student |
|----------------------|-------|----------|---------|
| Dashboard            | ✅    | ✅       | ✅      |
| Manage Students      | ✅    | 👁        | ❌      |
| Manage Lecturers     | ✅    | ❌       | ❌      |
| Manage Courses       | ✅    | 👁        | 👁       |
| Mark Attendance      | ✅    | ✅       | 👁       |
| Enter Marks          | ✅    | ✅       | 👁       |
| View Own Marks       | ❌    | ❌       | ✅      |
| View Own Attendance  | ❌    | ❌       | ✅      |

---

## 🚀 Setup Instructions

### Prerequisites

- **Node.js** v18+
- **MySQL** 8.0+
- **Git**

---

### Step 1 — Clone the Repository

```bash
git clone https://github.com/your-username/learnify-erp-system.git
cd learnify-erp-system
```

---

### Step 2 — Database Setup (Tables Only)

Create the tables by running the schema SQL (no seed data here):

```bash
mysql -u root -p < backend/config/schema.sql
```

Or open the file in MySQL Workbench / DBeaver and run it. This creates the `learnify_erp` database and all 7 tables.

---

### Step 3 — Backend Setup

```bash
cd backend
cp .env.example .env
```

Edit `.env` with your MySQL credentials:

```env
PORT=5000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password_here
DB_NAME=learnify_erp
JWT_SECRET=learnify_super_secret_jwt_key_2024
JWT_EXPIRES_IN=7d
```

Install dependencies and start:

```bash
npm install

# Seed the database with demo data (generates correct password hashes)
npm run seed

npm run dev      # Development (with nodemon)
# or
npm start        # Production
```

Backend will run at: **http://localhost:5000**

Test: Open http://localhost:5000/api/health

---

### Step 4 — Frontend Setup

```bash
cd ../frontend
npm install
npm run dev
```

Frontend will run at: **http://localhost:5173**

---

## 🔑 Demo Login Credentials

All accounts use the same seeded password. You can click the quick-login buttons on the login page.

| Role     | Email                  | Password   |
|----------|------------------------|------------|
| Admin    | admin@learnify.edu     | Admin@123  |
| Lecturer | rajesh@learnify.edu    | Admin@123  |
| Student  | amit@learnify.edu      | Admin@123  |

> **Note:** The seed data uses a pre-hashed bcrypt password. To use different passwords, register new users through the /register page or re-hash using bcrypt.

---

## 📡 API Endpoints

### Authentication
| Method | Endpoint             | Description        | Auth |
|--------|----------------------|--------------------|------|
| POST   | /api/auth/register   | Register user      | No   |
| POST   | /api/auth/login      | Login              | No   |
| GET    | /api/auth/me         | Get current user   | Yes  |

### Students
| Method | Endpoint             | Description         | Role       |
|--------|----------------------|---------------------|------------|
| GET    | /api/students        | List all students   | Admin/Lec  |
| GET    | /api/students/:id    | Get by ID           | Any        |
| PUT    | /api/students/:id    | Update              | Admin      |
| DELETE | /api/students/:id    | Delete              | Admin      |

### Lecturers
| Method | Endpoint                  | Description          | Role  |
|--------|---------------------------|----------------------|-------|
| GET    | /api/lecturers            | List all             | Admin |
| GET    | /api/lecturers/:id        | Get by ID            | Admin |
| GET    | /api/lecturers/:id/subjects | Get subjects       | Admin |
| DELETE | /api/lecturers/:id        | Delete               | Admin |

### Courses & Subjects
| Method | Endpoint            | Description       | Role  |
|--------|---------------------|-------------------|-------|
| GET    | /api/courses        | List courses      | Any   |
| POST   | /api/courses        | Create course     | Admin |
| PUT    | /api/courses/:id    | Update course     | Admin |
| DELETE | /api/courses/:id    | Delete course     | Admin |
| GET    | /api/subjects       | List subjects     | Any   |
| POST   | /api/subjects       | Create subject    | Admin |
| PUT    | /api/subjects/:id   | Update subject    | Admin |
| DELETE | /api/subjects/:id   | Delete subject    | Admin |

### Attendance
| Method | Endpoint                          | Description            | Role       |
|--------|-----------------------------------|------------------------|------------|
| POST   | /api/attendance                   | Mark attendance        | Admin/Lec  |
| GET    | /api/attendance/subject/:id       | By subject             | Admin/Lec  |
| GET    | /api/attendance/student/:id       | By student             | Any        |

### Marks
| Method | Endpoint                     | Description       | Role       |
|--------|------------------------------|-------------------|------------|
| POST   | /api/marks                   | Add marks         | Admin/Lec  |
| PUT    | /api/marks/:id               | Update marks      | Admin/Lec  |
| DELETE | /api/marks/:id               | Delete marks      | Admin      |
| GET    | /api/marks/student/:id       | Student marks     | Any        |
| GET    | /api/marks/subject/:id       | Subject marks     | Admin/Lec  |

### Dashboard
| Method | Endpoint               | Description         | Role     |
|--------|------------------------|---------------------|----------|
| GET    | /api/dashboard/admin   | Admin stats         | Admin    |
| GET    | /api/dashboard/lecturer| Lecturer stats      | Lecturer |
| GET    | /api/dashboard/student | Student stats       | Student  |

---

## ✨ Features

- 🔐 JWT Authentication with role-based access control
- 📊 Role-specific dashboards (Admin, Lecturer, Student)
- 🎓 Student enrollment and management
- 👨‍🏫 Lecturer management with subject assignment
- 📚 Course and subject CRUD
- 📋 Attendance marking with bulk toggle (present/absent)
- 📝 Marks entry with exam type classification
- 📈 Charts and analytics (Recharts)
- 📱 Fully responsive design (Tailwind CSS)
- 🔍 Search and filter functionality
- 🚨 Error handling and validation

---

## 🎨 UI Highlights

- Custom color scheme with indigo/violet primary palette
- Google Fonts: **Sora** (display) + **DM Sans** (body)
- Collapsible sidebar navigation
- Card-based stat displays
- Interactive attendance toggle cards
- Grade-color-coded marks display

---

## 📝 License

MIT License — Free to use for academic and educational purposes.

---

*Built with ❤️ for BCA/MCA final year project demonstration.*
