const express = require('express');
const router = express.Router();
const { getAllLecturers, getLecturerById, updateLecturer, deleteLecturer, getLecturerSubjects } = require('../controllers/lecturerController');
const { authenticate, authorizeRoles } = require('../middleware/auth');

router.use(authenticate);
router.get('/', authorizeRoles('admin'), getAllLecturers);
router.get('/:id', authorizeRoles('admin', 'lecturer'), getLecturerById);
router.get('/:id/subjects', authorizeRoles('admin', 'lecturer'), getLecturerSubjects);
router.put('/:id', authorizeRoles('admin'), updateLecturer);
router.delete('/:id', authorizeRoles('admin'), deleteLecturer);

module.exports = router;
