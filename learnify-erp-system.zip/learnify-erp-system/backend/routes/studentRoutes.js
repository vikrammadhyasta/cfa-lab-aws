const express = require('express');
const router = express.Router();
const { getAllStudents, getStudentById, updateStudent, deleteStudent, getStudentStats } = require('../controllers/studentController');
const { authenticate, authorizeRoles } = require('../middleware/auth');

router.use(authenticate);
router.get('/stats', authorizeRoles('admin'), getStudentStats);
router.get('/', authorizeRoles('admin', 'lecturer'), getAllStudents);
router.get('/:id', authorizeRoles('admin', 'lecturer', 'student'), getStudentById);
router.put('/:id', authorizeRoles('admin'), updateStudent);
router.delete('/:id', authorizeRoles('admin'), deleteStudent);

module.exports = router;
