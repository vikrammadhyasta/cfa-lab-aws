const express = require('express');
const router = express.Router();
const { markAttendance, getAttendanceBySubject, getStudentAttendance, getAttendanceStats } = require('../controllers/attendanceController');
const { authenticate, authorizeRoles } = require('../middleware/auth');

router.use(authenticate);
router.post('/', authorizeRoles('admin', 'lecturer'), markAttendance);
router.get('/stats', authorizeRoles('admin'), getAttendanceStats);
router.get('/subject/:subject_id', authorizeRoles('admin', 'lecturer'), getAttendanceBySubject);
router.get('/student/:student_id', getStudentAttendance);

module.exports = router;
