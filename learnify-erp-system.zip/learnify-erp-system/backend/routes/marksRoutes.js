const express = require('express');
const router = express.Router();
const { addMarks, updateMarks, deleteMarks, getStudentMarks, getMarksBySubject } = require('../controllers/marksController');
const { authenticate, authorizeRoles } = require('../middleware/auth');

router.use(authenticate);
router.post('/', authorizeRoles('admin', 'lecturer'), addMarks);
router.put('/:id', authorizeRoles('admin', 'lecturer'), updateMarks);
router.delete('/:id', authorizeRoles('admin'), deleteMarks);
router.get('/student/:student_id', getStudentMarks);
router.get('/subject/:subject_id', authorizeRoles('admin', 'lecturer'), getMarksBySubject);

module.exports = router;
