const express = require('express');
const router = express.Router();
const { getAdminDashboard, getLecturerDashboard, getStudentDashboard } = require('../controllers/dashboardController');
const { authenticate, authorizeRoles } = require('../middleware/auth');

router.use(authenticate);
router.get('/admin', authorizeRoles('admin'), getAdminDashboard);
router.get('/lecturer', authorizeRoles('lecturer'), getLecturerDashboard);
router.get('/student', authorizeRoles('student'), getStudentDashboard);

module.exports = router;
