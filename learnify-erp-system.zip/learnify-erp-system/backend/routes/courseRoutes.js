const express = require('express');
const router = express.Router();
const {
  getAllCourses, createCourse, updateCourse, deleteCourse,
  getAllSubjects, createSubject, updateSubject, deleteSubject
} = require('../controllers/courseController');
const { authenticate, authorizeRoles } = require('../middleware/auth');

router.use(authenticate);

// Courses
router.get('/courses', getAllCourses);
router.post('/courses', authorizeRoles('admin'), createCourse);
router.put('/courses/:id', authorizeRoles('admin'), updateCourse);
router.delete('/courses/:id', authorizeRoles('admin'), deleteCourse);

// Subjects
router.get('/subjects', getAllSubjects);
router.post('/subjects', authorizeRoles('admin'), createSubject);
router.put('/subjects/:id', authorizeRoles('admin'), updateSubject);
router.delete('/subjects/:id', authorizeRoles('admin'), deleteSubject);

module.exports = router;
