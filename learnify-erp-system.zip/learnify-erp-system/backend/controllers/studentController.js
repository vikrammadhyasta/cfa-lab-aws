const db = require('../config/db');

// GET /api/students
const getAllStudents = async (req, res, next) => {
  try {
    const [rows] = await db.query(`
      SELECT s.id, s.department, s.semester, s.college_id,
             u.id as user_id, u.name, u.email, u.created_at
      FROM students s
      JOIN users u ON s.user_id = u.id
      ORDER BY s.id DESC
    `);
    res.json({ success: true, data: rows });
  } catch (err) { next(err); }
};

// GET /api/students/:id
const getStudentById = async (req, res, next) => {
  try {
    const [rows] = await db.query(`
      SELECT s.id, s.department, s.semester, s.college_id,
             u.id as user_id, u.name, u.email, u.created_at
      FROM students s
      JOIN users u ON s.user_id = u.id
      WHERE s.id = ?
    `, [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ success: false, message: 'Student not found.' });
    res.json({ success: true, data: rows[0] });
  } catch (err) { next(err); }
};

// PUT /api/students/:id
const updateStudent = async (req, res, next) => {
  try {
    const { department, semester } = req.body;
    await db.query('UPDATE students SET department = ?, semester = ? WHERE id = ?',
      [department, semester, req.params.id]);
    res.json({ success: true, message: 'Student updated successfully.' });
  } catch (err) { next(err); }
};

// DELETE /api/students/:id
const deleteStudent = async (req, res, next) => {
  try {
    const [s] = await db.query('SELECT user_id FROM students WHERE id = ?', [req.params.id]);
    if (s.length === 0) return res.status(404).json({ success: false, message: 'Student not found.' });
    await db.query('DELETE FROM users WHERE id = ?', [s[0].user_id]);
    res.json({ success: true, message: 'Student deleted successfully.' });
  } catch (err) { next(err); }
};

// GET /api/students/stats
const getStudentStats = async (req, res, next) => {
  try {
    const [total] = await db.query('SELECT COUNT(*) as count FROM students');
    const [byDept] = await db.query('SELECT department, COUNT(*) as count FROM students GROUP BY department');
    const [bySem] = await db.query('SELECT semester, COUNT(*) as count FROM students GROUP BY semester ORDER BY semester');
    res.json({ success: true, data: { total: total[0].count, byDepartment: byDept, bySemester: bySem } });
  } catch (err) { next(err); }
};

module.exports = { getAllStudents, getStudentById, updateStudent, deleteStudent, getStudentStats };
