const db = require('../config/db');

// ---- COURSES ----
const getAllCourses = async (req, res, next) => {
  try {
    const [rows] = await db.query('SELECT * FROM courses ORDER BY id DESC');
    res.json({ success: true, data: rows });
  } catch (err) { next(err); }
};

const createCourse = async (req, res, next) => {
  try {
    const { course_name, department } = req.body;
    if (!course_name || !department)
      return res.status(400).json({ success: false, message: 'course_name and department are required.' });
    const [result] = await db.query('INSERT INTO courses (course_name, department) VALUES (?, ?)', [course_name, department]);
    res.status(201).json({ success: true, message: 'Course created.', id: result.insertId });
  } catch (err) { next(err); }
};

const updateCourse = async (req, res, next) => {
  try {
    const { course_name, department } = req.body;
    await db.query('UPDATE courses SET course_name = ?, department = ? WHERE id = ?',
      [course_name, department, req.params.id]);
    res.json({ success: true, message: 'Course updated.' });
  } catch (err) { next(err); }
};

const deleteCourse = async (req, res, next) => {
  try {
    await db.query('DELETE FROM courses WHERE id = ?', [req.params.id]);
    res.json({ success: true, message: 'Course deleted.' });
  } catch (err) { next(err); }
};

// ---- SUBJECTS ----
const getAllSubjects = async (req, res, next) => {
  try {
    const [rows] = await db.query(`
      SELECT sub.id, sub.subject_name, sub.course_id, sub.lecturer_id,
             c.course_name, c.department,
             u.name as lecturer_name
      FROM subjects sub
      JOIN courses c ON sub.course_id = c.id
      LEFT JOIN lecturers l ON sub.lecturer_id = l.id
      LEFT JOIN users u ON l.user_id = u.id
      ORDER BY sub.id DESC
    `);
    res.json({ success: true, data: rows });
  } catch (err) { next(err); }
};

const createSubject = async (req, res, next) => {
  try {
    const { subject_name, course_id, lecturer_id } = req.body;
    if (!subject_name || !course_id)
      return res.status(400).json({ success: false, message: 'subject_name and course_id are required.' });
    const [result] = await db.query(
      'INSERT INTO subjects (subject_name, course_id, lecturer_id) VALUES (?, ?, ?)',
      [subject_name, course_id, lecturer_id || null]
    );
    res.status(201).json({ success: true, message: 'Subject created.', id: result.insertId });
  } catch (err) { next(err); }
};

const updateSubject = async (req, res, next) => {
  try {
    const { subject_name, course_id, lecturer_id } = req.body;
    await db.query(
      'UPDATE subjects SET subject_name = ?, course_id = ?, lecturer_id = ? WHERE id = ?',
      [subject_name, course_id, lecturer_id || null, req.params.id]
    );
    res.json({ success: true, message: 'Subject updated.' });
  } catch (err) { next(err); }
};

const deleteSubject = async (req, res, next) => {
  try {
    await db.query('DELETE FROM subjects WHERE id = ?', [req.params.id]);
    res.json({ success: true, message: 'Subject deleted.' });
  } catch (err) { next(err); }
};

module.exports = {
  getAllCourses, createCourse, updateCourse, deleteCourse,
  getAllSubjects, createSubject, updateSubject, deleteSubject
};
