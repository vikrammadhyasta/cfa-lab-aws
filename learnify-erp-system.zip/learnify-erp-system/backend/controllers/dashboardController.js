const db = require('../config/db');

const getAdminDashboard = async (req, res, next) => {
  try {
    const [[{ students }]] = await db.query('SELECT COUNT(*) as students FROM students');
    const [[{ lecturers }]] = await db.query('SELECT COUNT(*) as lecturers FROM lecturers');
    const [[{ courses }]] = await db.query('SELECT COUNT(*) as courses FROM courses');
    const [[{ subjects }]] = await db.query('SELECT COUNT(*) as subjects FROM subjects');
    const [[{ attendance_pct }]] = await db.query(`
      SELECT ROUND(SUM(CASE WHEN status='present' THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*),0), 1) as attendance_pct
      FROM attendance
    `);
    const [recentStudents] = await db.query(`
      SELECT u.name, s.college_id, s.department, s.semester, u.created_at
      FROM students s JOIN users u ON s.user_id = u.id
      ORDER BY s.id DESC LIMIT 5
    `);
    const [deptDist] = await db.query('SELECT department, COUNT(*) as count FROM students GROUP BY department');

    res.json({
      success: true,
      data: {
        stats: { students, lecturers, courses, subjects, attendance_pct: attendance_pct || 0 },
        recentStudents,
        deptDistribution: deptDist
      }
    });
  } catch (err) { next(err); }
};

const getLecturerDashboard = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const [[lecturer]] = await db.query('SELECT id FROM lecturers WHERE user_id = ?', [userId]);
    if (!lecturer) return res.status(404).json({ success: false, message: 'Lecturer profile not found.' });

    const [subjects] = await db.query(`
      SELECT sub.id, sub.subject_name, c.course_name, c.department,
             (SELECT COUNT(DISTINCT student_id) FROM attendance WHERE subject_id = sub.id) as student_count
      FROM subjects sub JOIN courses c ON sub.course_id = c.id
      WHERE sub.lecturer_id = ?
    `, [lecturer.id]);

    const [[{ total_marks }]] = await db.query(
      'SELECT COUNT(*) as total_marks FROM marks m JOIN subjects s ON m.subject_id = s.id WHERE s.lecturer_id = ?',
      [lecturer.id]
    );

    res.json({ success: true, data: { subjects, stats: { subjects: subjects.length, total_marks } } });
  } catch (err) { next(err); }
};

const getStudentDashboard = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const [[student]] = await db.query('SELECT * FROM students WHERE user_id = ?', [userId]);
    if (!student) return res.status(404).json({ success: false, message: 'Student profile not found.' });

    const [[{ total }]] = await db.query('SELECT COUNT(*) as total FROM attendance WHERE student_id = ?', [student.id]);
    const [[{ present }]] = await db.query('SELECT COUNT(*) as present FROM attendance WHERE student_id = ? AND status = "present"', [student.id]);
    const pct = total > 0 ? ((present / total) * 100).toFixed(1) : 0;

    const [recentMarks] = await db.query(`
      SELECT m.marks, m.exam_type, sub.subject_name
      FROM marks m JOIN subjects sub ON m.subject_id = sub.id
      WHERE m.student_id = ?
      ORDER BY m.created_at DESC LIMIT 5
    `, [student.id]);

    const [subjects] = await db.query(`
      SELECT sub.id, sub.subject_name, c.course_name, u.name as lecturer_name
      FROM subjects sub
      JOIN courses c ON sub.course_id = c.id
      LEFT JOIN lecturers l ON sub.lecturer_id = l.id
      LEFT JOIN users u ON l.user_id = u.id
      WHERE c.department = ?
    `, [student.department]);

    res.json({
      success: true,
      data: {
        student,
        stats: { total_classes: total, present, absent: total - present, attendance_pct: pct },
        recentMarks,
        subjects
      }
    });
  } catch (err) { next(err); }
};

module.exports = { getAdminDashboard, getLecturerDashboard, getStudentDashboard };
