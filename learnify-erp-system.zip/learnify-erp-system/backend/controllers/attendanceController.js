const db = require('../config/db');

// POST /api/attendance - Mark attendance (lecturer/admin)
const markAttendance = async (req, res, next) => {
  try {
    const { subject_id, date, records } = req.body;
    // records: [{ student_id, status }]
    if (!subject_id || !date || !records || records.length === 0) {
      return res.status(400).json({ success: false, message: 'subject_id, date, and records are required.' });
    }

    const values = records.map(r => [r.student_id, subject_id, date, r.status]);
    await db.query(
      `INSERT INTO attendance (student_id, subject_id, date, status) VALUES ?
       ON DUPLICATE KEY UPDATE status = VALUES(status)`,
      [values]
    );

    res.json({ success: true, message: 'Attendance marked successfully.' });
  } catch (err) { next(err); }
};

// GET /api/attendance/subject/:subject_id?date=YYYY-MM-DD
const getAttendanceBySubject = async (req, res, next) => {
  try {
    const { subject_id } = req.params;
    const { date } = req.query;

    let query = `
      SELECT a.id, a.date, a.status,
             s.id as student_id, u.name as student_name, s.college_id
      FROM attendance a
      JOIN students s ON a.student_id = s.id
      JOIN users u ON s.user_id = u.id
      WHERE a.subject_id = ?
    `;
    const params = [subject_id];
    if (date) { query += ' AND a.date = ?'; params.push(date); }
    query += ' ORDER BY a.date DESC, u.name';

    const [rows] = await db.query(query, params);
    res.json({ success: true, data: rows });
  } catch (err) { next(err); }
};

// GET /api/attendance/student/:student_id
const getStudentAttendance = async (req, res, next) => {
  try {
    const { student_id } = req.params;
    const [rows] = await db.query(`
      SELECT a.id, a.date, a.status,
             sub.subject_name, c.course_name
      FROM attendance a
      JOIN subjects sub ON a.subject_id = sub.id
      JOIN courses c ON sub.course_id = c.id
      WHERE a.student_id = ?
      ORDER BY a.date DESC
    `, [student_id]);

    // Summary per subject
    const [summary] = await db.query(`
      SELECT sub.subject_name,
             COUNT(*) as total,
             SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present,
             SUM(CASE WHEN a.status = 'absent' THEN 1 ELSE 0 END) as absent,
             ROUND(SUM(CASE WHEN a.status='present' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as percentage
      FROM attendance a
      JOIN subjects sub ON a.subject_id = sub.id
      WHERE a.student_id = ?
      GROUP BY sub.id, sub.subject_name
    `, [student_id]);

    res.json({ success: true, data: rows, summary });
  } catch (err) { next(err); }
};

// GET /api/attendance/stats
const getAttendanceStats = async (req, res, next) => {
  try {
    const [overall] = await db.query(`
      SELECT
        COUNT(*) as total_records,
        SUM(CASE WHEN status='present' THEN 1 ELSE 0 END) as total_present,
        ROUND(SUM(CASE WHEN status='present' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as overall_percentage
      FROM attendance
    `);
    res.json({ success: true, data: overall[0] });
  } catch (err) { next(err); }
};

module.exports = { markAttendance, getAttendanceBySubject, getStudentAttendance, getAttendanceStats };
