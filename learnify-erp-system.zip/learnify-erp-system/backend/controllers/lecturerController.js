const db = require('../config/db');

const getAllLecturers = async (req, res, next) => {
  try {
    const [rows] = await db.query(`
      SELECT l.id, l.department, l.employee_id,
             u.id as user_id, u.name, u.email, u.created_at
      FROM lecturers l
      JOIN users u ON l.user_id = u.id
      ORDER BY l.id DESC
    `);
    res.json({ success: true, data: rows });
  } catch (err) { next(err); }
};

const getLecturerById = async (req, res, next) => {
  try {
    const [rows] = await db.query(`
      SELECT l.id, l.department, l.employee_id,
             u.id as user_id, u.name, u.email, u.created_at
      FROM lecturers l
      JOIN users u ON l.user_id = u.id
      WHERE l.id = ?
    `, [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ success: false, message: 'Lecturer not found.' });
    res.json({ success: true, data: rows[0] });
  } catch (err) { next(err); }
};

const updateLecturer = async (req, res, next) => {
  try {
    const { department } = req.body;
    await db.query('UPDATE lecturers SET department = ? WHERE id = ?', [department, req.params.id]);
    res.json({ success: true, message: 'Lecturer updated.' });
  } catch (err) { next(err); }
};

const deleteLecturer = async (req, res, next) => {
  try {
    const [l] = await db.query('SELECT user_id FROM lecturers WHERE id = ?', [req.params.id]);
    if (l.length === 0) return res.status(404).json({ success: false, message: 'Lecturer not found.' });
    await db.query('DELETE FROM users WHERE id = ?', [l[0].user_id]);
    res.json({ success: true, message: 'Lecturer deleted.' });
  } catch (err) { next(err); }
};

const getLecturerSubjects = async (req, res, next) => {
  try {
    const lecturerId = req.params.id;
    const [rows] = await db.query(`
      SELECT sub.id, sub.subject_name, c.course_name, c.department
      FROM subjects sub
      JOIN courses c ON sub.course_id = c.id
      WHERE sub.lecturer_id = ?
    `, [lecturerId]);
    res.json({ success: true, data: rows });
  } catch (err) { next(err); }
};

module.exports = { getAllLecturers, getLecturerById, updateLecturer, deleteLecturer, getLecturerSubjects };
