const db = require('../config/db');

// POST /api/marks
const addMarks = async (req, res, next) => {
  try {
    const { student_id, subject_id, marks, exam_type } = req.body;
    if (!student_id || !subject_id || marks === undefined || !exam_type) {
      return res.status(400).json({ success: false, message: 'All fields are required.' });
    }
    const [result] = await db.query(
      'INSERT INTO marks (student_id, subject_id, marks, exam_type) VALUES (?, ?, ?, ?)',
      [student_id, subject_id, marks, exam_type]
    );
    res.status(201).json({ success: true, message: 'Marks added.', id: result.insertId });
  } catch (err) { next(err); }
};

// PUT /api/marks/:id
const updateMarks = async (req, res, next) => {
  try {
    const { marks, exam_type } = req.body;
    await db.query('UPDATE marks SET marks = ?, exam_type = ? WHERE id = ?', [marks, exam_type, req.params.id]);
    res.json({ success: true, message: 'Marks updated.' });
  } catch (err) { next(err); }
};

// DELETE /api/marks/:id
const deleteMarks = async (req, res, next) => {
  try {
    await db.query('DELETE FROM marks WHERE id = ?', [req.params.id]);
    res.json({ success: true, message: 'Marks deleted.' });
  } catch (err) { next(err); }
};

// GET /api/marks/student/:student_id
const getStudentMarks = async (req, res, next) => {
  try {
    const [rows] = await db.query(`
      SELECT m.id, m.marks, m.exam_type, m.created_at,
             sub.subject_name, c.course_name
      FROM marks m
      JOIN subjects sub ON m.subject_id = sub.id
      JOIN courses c ON sub.course_id = c.id
      WHERE m.student_id = ?
      ORDER BY m.created_at DESC
    `, [req.params.student_id]);

    const [summary] = await db.query(`
      SELECT sub.subject_name, m.exam_type,
             AVG(m.marks) as average, MAX(m.marks) as highest, MIN(m.marks) as lowest
      FROM marks m
      JOIN subjects sub ON m.subject_id = sub.id
      WHERE m.student_id = ?
      GROUP BY sub.id, sub.subject_name, m.exam_type
    `, [req.params.student_id]);

    res.json({ success: true, data: rows, summary });
  } catch (err) { next(err); }
};

// GET /api/marks/subject/:subject_id
const getMarksBySubject = async (req, res, next) => {
  try {
    const { exam_type } = req.query;
    let query = `
      SELECT m.id, m.marks, m.exam_type, m.created_at,
             u.name as student_name, s.college_id
      FROM marks m
      JOIN students s ON m.student_id = s.id
      JOIN users u ON s.user_id = u.id
      WHERE m.subject_id = ?
    `;
    const params = [req.params.subject_id];
    if (exam_type) { query += ' AND m.exam_type = ?'; params.push(exam_type); }
    query += ' ORDER BY u.name';

    const [rows] = await db.query(query, params);
    res.json({ success: true, data: rows });
  } catch (err) { next(err); }
};

module.exports = { addMarks, updateMarks, deleteMarks, getStudentMarks, getMarksBySubject };
