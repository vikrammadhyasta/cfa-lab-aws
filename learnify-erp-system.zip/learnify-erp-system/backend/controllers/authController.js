const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db');
require('dotenv').config();

const generateToken = (user) => {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role, name: user.name },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
};

// POST /api/auth/register
const register = async (req, res, next) => {
  try {
    const { name, email, password, role, department, semester, college_id, employee_id } = req.body;

    if (!name || !email || !password || !role) {
      return res.status(400).json({ success: false, message: 'Name, email, password, and role are required.' });
    }

    const [existing] = await db.query('SELECT id FROM users WHERE email = ?', [email]);
    if (existing.length > 0) {
      return res.status(409).json({ success: false, message: 'Email already registered.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const [userResult] = await db.query(
      'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
      [name, email, hashedPassword, role]
    );
    const userId = userResult.insertId;

    if (role === 'student') {
      if (!department || !college_id) {
        return res.status(400).json({ success: false, message: 'Department and college_id required for students.' });
      }
      await db.query(
        'INSERT INTO students (user_id, department, semester, college_id) VALUES (?, ?, ?, ?)',
        [userId, department, semester || 1, college_id]
      );
    } else if (role === 'lecturer') {
      if (!department || !employee_id) {
        return res.status(400).json({ success: false, message: 'Department and employee_id required for lecturers.' });
      }
      await db.query(
        'INSERT INTO lecturers (user_id, department, employee_id) VALUES (?, ?, ?)',
        [userId, department, employee_id]
      );
    }

    res.status(201).json({ success: true, message: 'User registered successfully.' });
  } catch (err) {
    next(err);
  }
};

// POST /api/auth/login
const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password are required.' });
    }

    const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length === 0) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    const user = rows[0];
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    // Get role-specific profile
    let profile = null;
    if (user.role === 'student') {
      const [s] = await db.query('SELECT * FROM students WHERE user_id = ?', [user.id]);
      profile = s[0] || null;
    } else if (user.role === 'lecturer') {
      const [l] = await db.query('SELECT * FROM lecturers WHERE user_id = ?', [user.id]);
      profile = l[0] || null;
    }

    const token = generateToken(user);

    res.json({
      success: true,
      message: 'Login successful.',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        profile
      }
    });
  } catch (err) {
    next(err);
  }
};

// GET /api/auth/me
const getMe = async (req, res, next) => {
  try {
    const [rows] = await db.query('SELECT id, name, email, role, created_at FROM users WHERE id = ?', [req.user.id]);
    if (rows.length === 0) return res.status(404).json({ success: false, message: 'User not found.' });

    const user = rows[0];
    let profile = null;
    if (user.role === 'student') {
      const [s] = await db.query('SELECT * FROM students WHERE user_id = ?', [user.id]);
      profile = s[0] || null;
    } else if (user.role === 'lecturer') {
      const [l] = await db.query('SELECT * FROM lecturers WHERE user_id = ?', [user.id]);
      profile = l[0] || null;
    }

    res.json({ success: true, user: { ...user, profile } });
  } catch (err) {
    next(err);
  }
};

module.exports = { register, login, getMe };
