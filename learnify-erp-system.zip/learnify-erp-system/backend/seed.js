/**
 * Learnify ERP - Database Seed Script
 * Run: node seed.js
 * This generates correct bcrypt hashes and seeds the database.
 */

require('dotenv').config();
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');

const DB_CONFIG = {
  host:     process.env.DB_HOST     || 'localhost',
  user:     process.env.DB_USER     || 'root',
  password: process.env.DB_PASSWORD || '',
  multipleStatements: true,
};

async function seed() {
  let conn;
  try {
    conn = await mysql.createConnection(DB_CONFIG);
    console.log('✅ Connected to MySQL');

    // Create & use database
    await conn.query(`CREATE DATABASE IF NOT EXISTS ${process.env.DB_NAME || 'learnify_erp'}`);
    await conn.query(`USE ${process.env.DB_NAME || 'learnify_erp'}`);
    console.log('✅ Database selected');

    // Create tables
    await conn.query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(150) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role ENUM('admin','lecturer','student') NOT NULL DEFAULT 'student',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);

    await conn.query(`
      CREATE TABLE IF NOT EXISTS students (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        department VARCHAR(100) NOT NULL,
        semester INT NOT NULL DEFAULT 1,
        college_id VARCHAR(50) NOT NULL UNIQUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `);

    await conn.query(`
      CREATE TABLE IF NOT EXISTS lecturers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        department VARCHAR(100) NOT NULL,
        employee_id VARCHAR(50) NOT NULL UNIQUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `);

    await conn.query(`
      CREATE TABLE IF NOT EXISTS courses (
        id INT AUTO_INCREMENT PRIMARY KEY,
        course_name VARCHAR(150) NOT NULL,
        department VARCHAR(100) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await conn.query(`
      CREATE TABLE IF NOT EXISTS subjects (
        id INT AUTO_INCREMENT PRIMARY KEY,
        subject_name VARCHAR(150) NOT NULL,
        course_id INT NOT NULL,
        lecturer_id INT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
        FOREIGN KEY (lecturer_id) REFERENCES lecturers(id) ON DELETE SET NULL
      )
    `);

    await conn.query(`
      CREATE TABLE IF NOT EXISTS attendance (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        subject_id INT NOT NULL,
        date DATE NOT NULL,
        status ENUM('present','absent') NOT NULL DEFAULT 'absent',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
        FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
        UNIQUE KEY unique_attendance (student_id, subject_id, date)
      )
    `);

    await conn.query(`
      CREATE TABLE IF NOT EXISTS marks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        subject_id INT NOT NULL,
        marks DECIMAL(5,2) NOT NULL,
        exam_type ENUM('internal','midterm','final','assignment') NOT NULL DEFAULT 'internal',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
        FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
      )
    `);

    console.log('✅ All tables created');

    // Check if already seeded
    const [existing] = await conn.query("SELECT COUNT(*) as cnt FROM users");
    if (existing[0].cnt > 0) {
      console.log('⚠️  Users already exist — skipping seed data. Drop tables and re-run to reseed.');
      await conn.end();
      return;
    }

    // Generate hashes
    const adminHash    = bcrypt.hashSync('Admin@123', 10);
    const lecHash      = bcrypt.hashSync('Admin@123', 10);
    const studentHash  = bcrypt.hashSync('Admin@123', 10);

    console.log('✅ Passwords hashed');

    // Seed users
    const [adminResult] = await conn.query(
      'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
      ['Admin User', 'admin@learnify.edu', adminHash, 'admin']
    );

    const [lec1Result] = await conn.query(
      'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
      ['Dr. Rajesh Kumar', 'rajesh@learnify.edu', lecHash, 'lecturer']
    );

    const [lec2Result] = await conn.query(
      'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
      ['Prof. Priya Sharma', 'priya@learnify.edu', lecHash, 'lecturer']
    );

    const [stu1Result] = await conn.query(
      'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
      ['Amit Patel', 'amit@learnify.edu', studentHash, 'student']
    );

    const [stu2Result] = await conn.query(
      'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
      ['Sneha Reddy', 'sneha@learnify.edu', studentHash, 'student']
    );

    console.log('✅ Users seeded');

    // Seed lecturers
    const [lecA] = await conn.query(
      'INSERT INTO lecturers (user_id, department, employee_id) VALUES (?, ?, ?)',
      [lec1Result.insertId, 'Computer Science', 'EMP001']
    );
    const [lecB] = await conn.query(
      'INSERT INTO lecturers (user_id, department, employee_id) VALUES (?, ?, ?)',
      [lec2Result.insertId, 'Mathematics', 'EMP002']
    );

    // Seed students
    const [stuA] = await conn.query(
      'INSERT INTO students (user_id, department, semester, college_id) VALUES (?, ?, ?, ?)',
      [stu1Result.insertId, 'Computer Science', 3, 'BCA2022001']
    );
    const [stuB] = await conn.query(
      'INSERT INTO students (user_id, department, semester, college_id) VALUES (?, ?, ?, ?)',
      [stu2Result.insertId, 'Computer Science', 3, 'BCA2022002']
    );

    console.log('✅ Lecturers & Students seeded');

    // Seed courses
    const [crs1] = await conn.query(
      'INSERT INTO courses (course_name, department) VALUES (?, ?)',
      ['Bachelor of Computer Applications', 'Computer Science']
    );
    const [crs2] = await conn.query(
      'INSERT INTO courses (course_name, department) VALUES (?, ?)',
      ['Master of Computer Applications', 'Computer Science']
    );

    // Seed subjects
    const [sub1] = await conn.query(
      'INSERT INTO subjects (subject_name, course_id, lecturer_id) VALUES (?, ?, ?)',
      ['Data Structures', crs1.insertId, lecA.insertId]
    );
    const [sub2] = await conn.query(
      'INSERT INTO subjects (subject_name, course_id, lecturer_id) VALUES (?, ?, ?)',
      ['Database Management Systems', crs1.insertId, lecA.insertId]
    );
    const [sub3] = await conn.query(
      'INSERT INTO subjects (subject_name, course_id, lecturer_id) VALUES (?, ?, ?)',
      ['Web Technology', crs1.insertId, lecB.insertId]
    );
    const [sub4] = await conn.query(
      'INSERT INTO subjects (subject_name, course_id, lecturer_id) VALUES (?, ?, ?)',
      ['Operating Systems', crs2.insertId, lecA.insertId]
    );

    console.log('✅ Courses & Subjects seeded');

    // Seed attendance
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    const dayBefore = new Date(Date.now() - 172800000).toISOString().split('T')[0];

    const attendanceData = [
      [stuA.insertId, sub1.insertId, dayBefore, 'present'],
      [stuA.insertId, sub1.insertId, yesterday, 'present'],
      [stuA.insertId, sub1.insertId, today,     'absent'],
      [stuA.insertId, sub2.insertId, dayBefore, 'present'],
      [stuA.insertId, sub2.insertId, yesterday, 'present'],
      [stuB.insertId, sub1.insertId, dayBefore, 'absent'],
      [stuB.insertId, sub1.insertId, yesterday, 'present'],
      [stuB.insertId, sub1.insertId, today,     'present'],
      [stuB.insertId, sub2.insertId, dayBefore, 'present'],
      [stuB.insertId, sub2.insertId, yesterday, 'absent'],
    ];

    for (const a of attendanceData) {
      await conn.query(
        'INSERT INTO attendance (student_id, subject_id, date, status) VALUES (?, ?, ?, ?)', a
      );
    }

    // Seed marks
    const marksData = [
      [stuA.insertId, sub1.insertId, 85.50, 'internal'],
      [stuA.insertId, sub2.insertId, 78.00, 'internal'],
      [stuA.insertId, sub1.insertId, 90.00, 'midterm'],
      [stuA.insertId, sub3.insertId, 88.00, 'assignment'],
      [stuB.insertId, sub1.insertId, 72.50, 'internal'],
      [stuB.insertId, sub2.insertId, 88.00, 'internal'],
      [stuB.insertId, sub1.insertId, 76.00, 'midterm'],
      [stuB.insertId, sub3.insertId, 92.00, 'assignment'],
    ];

    for (const m of marksData) {
      await conn.query(
        'INSERT INTO marks (student_id, subject_id, marks, exam_type) VALUES (?, ?, ?, ?)', m
      );
    }

    console.log('✅ Attendance & Marks seeded');
    console.log('\n🎉 Database seeded successfully!\n');
    console.log('Demo Login Credentials:');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('Admin    → admin@learnify.edu   / Admin@123');
    console.log('Lecturer → rajesh@learnify.edu  / Admin@123');
    console.log('Student  → amit@learnify.edu    / Admin@123');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

    await conn.end();
  } catch (err) {
    console.error('❌ Seed failed:', err.message);
    if (conn) await conn.end();
    process.exit(1);
  }
}

seed();
